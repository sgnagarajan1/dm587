# Odense weather teaching dataset

Daily ERA5 reanalysis near Odense, 1 January 2006–31 December 2025. Retrieved 27 October 2026 from Open-Meteo's Historical Weather API. These are gridded reanalysis estimates combining observations and a weather model, not readings from a named local weather station.

Requested coordinates: 55.4038 N, 10.4024 E. Returned ERA5 grid point: 55.5 N, 10.5 E; API elevation 14 m. Model explicitly fixed to ERA5 for consistency. API timezone: Europe/Copenhagen. Temperature is air temperature at 2 m, in degrees Celsius; precipitation is daily total in millimetres.

Source request:
https://archive-api.open-meteo.com/v1/archive?latitude=55.4038&longitude=10.4024&start_date=2006-01-01&end_date=2025-12-31&daily=temperature_2m_mean,temperature_2m_min,temperature_2m_max,precipitation_sum&models=era5&timezone=Europe%2FCopenhagen

Original response: odense-era5-2006-2025.json. Teaching extract: odense-weather.csv. Changes: selected variables, renamed columns and converted the daily JSON arrays into CSV rows. Values are unchanged. All 7,305 dates are unique and consecutive, and selected variables contain no missing values. Derived monthly means and model predictions are calculations made for this lecture, not extra observations.

Weather data by Open-Meteo: https://open-meteo.com/ . Data licence: CC BY 4.0, https://creativecommons.org/licenses/by/4.0/ . Documentation: https://open-meteo.com/en/docs/historical-weather-api . Contains modified Copernicus Climate Change Service information (2026). Neither the European Commission nor ECMWF is responsible for use of the Copernicus information or data. ERA5: https://cds.climate.copernicus.eu/datasets/reanalysis-era5-single-levels .

Forecasting is a teaching backtest: train through December 2023, evaluate January 2024–December 2025. The final projection uses observations only through December 2025; it is not a live operational weather forecast. Twenty years at one grid point do not establish a global climate trend or its causes.
